#include "signal.h"

Signal::Signal(QString p, QString f, QString c, QString l){
    path=p;
    fs=f;
    canales=c;
    leerDesde=l;
}

Signal::Signal(){
    path="";
    fs="0";
    canales="0";
    leerDesde="0";


}

QString Signal::toString(){

    QString str="Path:"+path+" Fs:"+fs+
            " Canales:"+canales+" leerDesde:"+leerDesde;
    return str;
}
