#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDirModel>
#include "qcustomplot.h"
#include <cargadatos.h>
#include <signal.h>
#include <QtSql/QSqlDatabase>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void SetRangoMax(int);
    void addILineToGraphs(int, int);
    void crearTreeView();
    bool upOctave();
    bool upDataBase();
    bool leer();
    bool ready();
    void writeInOctave();
    bool levantarServicios();
public slots:
    void horzSliderChangedA(int value);
    void horzSliderChangedB(int value);



private slots:
    void on_actionAdd_Edit_Remove_User_triggered();
    void on_actionOpen_triggered();
    void setDatos(Signal *s);

    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;
    CargaDatos *dialogoFile;
    Signal *signal;
    QCPItemLine *itemA, *itemB;
    QDirModel *model;
    QProcess *octave;
    QSqlDatabase db;
};

#endif // MAINWINDOW_H
