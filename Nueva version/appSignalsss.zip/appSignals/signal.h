#ifndef SIGNAL_H
#define SIGNAL_H

#include <QMainWindow>
#include <QObject>
#include <QList>
#include <QVector2D>

class Signal
{
public:
    Signal();
    Signal(QString p, QString f, QString c, QString l);
    QVector<QVector <double> > readSignal;
    //getters and setters
    QString getPath(){return path;}
    QString getFs(){return fs;}
    QString getCanales(){return canales;}
    QString getLeerDesde(){return leerDesde;}
    QString getSeparador(){return separador;}
    QVector<QVector <double> > getreadSignal(){return readSignal;}
    void setPath(QString s){path=s;}
    void setFs(QString f){fs=f;}
    void setCanales(QString c){canales=c;}
    void setLeerDesde(QString l){leerDesde=l;}
    void setSeparador(QString l){separador=l;}
    /*void setReadSignal(int c){
                            readSignal.resize(c);
                            for (int i = 0; i < c; i++){
                                QVector<double> q;
                                q.append(12.0);
                                readSignal[i]=q;
                            }
                         }*/
    QString toString();

private:
    QString path,fs,canales,leerDesde,separador;

    //FFT,Wavelet,Gabor-Wigner

};

#endif // SIGNAL_H
