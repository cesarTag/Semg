#ifndef CARGADATOS_H
#define CARGADATOS_H

#include <QDialog>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include <QListWidgetItem>
#include <signal.h>


namespace Ui {
class CargaDatos;
}

class CargaDatos : public QDialog
{
    Q_OBJECT

public:
    explicit CargaDatos(QWidget *parent = 0);

    ~CargaDatos();

    void habilita(QString tipo, QString path);

signals:
    void lecturaAceptada(Signal *s);


private slots:
    void on_ButtonAccept_clicked();
    void fileChooser();

private:
    Ui::CargaDatos *ui;
    Signal *signal;
    void createIcons();

};

#endif // CARGADATOS_H
