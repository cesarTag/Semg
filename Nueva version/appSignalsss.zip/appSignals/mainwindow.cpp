#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDirModel>
#include <QTreeView>
#include <QInputDialog>

#include "userform.h"


MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow){
    ui->setupUi(this);
    signal=new Signal();
    crearTreeView();

    // Se conectan los Slider con las SpinBox del grafico---------------------------------------------------------------------------- Editado!
    addILineToGraphs(50000, 1000);
    SetRangoMax(50000/1000);

    ui->horizontalSlider->setHandleMovementMode(QxtSpanSlider::NoOverlapping);
    ui->horizontalSlider->setUpperPosition(ui->horizontalSlider->maximum());

    connect(ui->horizontalSlider, SIGNAL(lowerValueChanged(int)), this, SLOT(horzSliderChangedA(int)));
    connect(ui->horizontalSlider, SIGNAL(upperValueChanged(int)), this, SLOT(horzSliderChangedB(int)));
    connect(ui->actionOpen,SIGNAL(triggered()),this,SLOT(on_actionOpen_triggered()));
}

MainWindow::~MainWindow(){
    delete ui;
}

void MainWindow::horzSliderChangedA(int value){

    double sliderA = value;
    //qDebug() << sliderA;
    ui->spinBoxInicio->setValue(value);

    itemA->start->setCoords(sliderA,-5000);
    itemA->end->setCoords(sliderA,5000);
    ui->grafico1->replot();
}

void MainWindow::horzSliderChangedB(int value)
{
    double sliderB = value;
    //qDebug() << sliderB;
    ui->spinBoxFin->setValue(value);

    itemB->start->setCoords(sliderB,-5000);
    itemB->end->setCoords(sliderB,5000);
    ui->grafico1->replot();
}

void MainWindow::SetRangoMax(int value){
    ui->horizontalSlider->setRange(0, value);
    ui->spinBoxInicio->setMaximum(value);
    ui->spinBoxFin->setMaximum(value);
}

void MainWindow::addILineToGraphs(int size, int frecMuestreo){

    itemA = new QCPItemLine(ui->grafico1);
    ui->grafico1->addItem(itemA);
    itemA->setPen(QPen(Qt::red));
    itemA->start->setCoords(0,-5000);
    itemA->end->setCoords(0,5000);

    itemB = new QCPItemLine(ui->grafico1);
    ui->grafico1->addItem(itemB);
    itemB->setPen(QPen(Qt::red));
    itemB->start->setCoords(size/frecMuestreo,-5000);
    itemB->end->setCoords(size/frecMuestreo,5000);

    ui->grafico1->setInteractions(QCP::iRangeDrag|QCP::iRangeZoom);
}

void MainWindow::crearTreeView(){
    // Create and populate our model
    model = new QDirModel(this);

    // Enable modifying file system
    model->setReadOnly(false);

    ui->treeView->setModel(model);

    model->setSorting(QDir::DirsFirst | QDir::IgnoreCase | QDir::Name);

    // Set initial selection
    QModelIndex index = model->index("C:/");
    ui->treeView->expand(index);
    ui->treeView->scrollTo(index);
    ui->treeView->setCurrentIndex(index);

    ui->treeView->setAnimated(true);

}


//=====================================================================================================//
//                            ||        FUNCIONES DE LOS MENUS       ||

void MainWindow::on_actionAdd_Edit_Remove_User_triggered()
{
    UserForm *w = new UserForm();
    w->setWindowModality(Qt::WindowModal);



    w->show();
}



void MainWindow::on_actionOpen_triggered(){

    dialogoFile=new CargaDatos();
    connect(dialogoFile,SIGNAL( lecturaAceptada(Signal*) ),
            this,SLOT( setDatos(Signal*) ) );
    dialogoFile->exec();
    dialogoFile->close();

}

void MainWindow::setDatos(Signal *s){

    qDebug()<<s->toString();
    signal->setCanales(s->getCanales());
    signal->setFs(s->getFs());
    signal->setLeerDesde(s->getLeerDesde());
    signal->setPath(s->getPath());
    signal->setSeparador(s->getSeparador());
    //signal->setReadSignal(s->getCanales().toInt()+1);

    qDebug()<<signal->toString();
    leer();
}


bool MainWindow::levantarServicios(){

    if(upDataBase() && upOctave())
        return true;

    return false;
}

/**********************************************************
 * @name:upDatabase
 * @brief: levanta una instancia de la base de datos
 * @return: bool, true si es correcto
 * ********************************************************/
bool MainWindow::upDataBase(){

    db = QSqlDatabase::addDatabase("QSQLITE");

    db.setDatabaseName(QString("pacientes"));

    if (!db.open()){

        QSqlDatabase::database("pacientes", false).close();
        QSqlDatabase::removeDatabase(QString("pacientes"));

        QMessageBox::critical(0, "No se puede abrir la base de datos",
        "Imposible establecer una conexi_n con la base de datos.\n"
        "Pulsar Cancel para salir.", QMessageBox::Cancel);
        return false;
        qDebug()<<"no inicio correctamente la base de datos: ";
    }
    else
        qDebug()<<"inicio correctamente la base de datos";


    return true;
}


void MainWindow::writeInOctave(){


    qDebug()<<"entra a openoctave";
    QString cmd;
    //QString cmd="menuOctave1 "+path+" "+opcion+"\n";
    //QString cmd="X=menuOctave('"+path+"','"+separador+"',"+fila+
    //        ","+canales+","+fs+",100"+",200"+",1,'"+opcion+"')\n";
    //qDebug()<<"comando a enviar:"<<cmd;

    if (octave->state()!=QProcess::Running)
        qDebug() << "El proceso no esta corriendo:" << octave->errorString()<<endl;
    else{
        octave->write(cmd.toUtf8());

    }
    QStringList salida;
    while(octave->waitForReadyRead()){

        salida.append(QString(octave->readAll()).split(" "));
        if(salida.last()=="fin"){
            qDebug()<< "salio del ciclo de lectura ";
            break;
        }
    }


}


bool MainWindow::upOctave(){

    octave=new QProcess(this);
    octave->setProcessChannelMode(QProcess::MergedChannels);
    octave->start("octave",QStringList()<<"-q"<<"-i");
    if (!octave->waitForStarted(15000)){
        qDebug() <<"(esperando inicio) no inicio"<<octave->processId()<< endl;
        return false;
    }
    qDebug()<<"octave ok";
    return true;
}


bool MainWindow::leer(){

    QFile fin(signal->getPath());

    if (!fin.open(QIODevice::ReadOnly | QIODevice::Text)){
        qDebug()<<"error al abrir el archivo en "<<signal->getPath();
        return false;
    }
    QTextStream in(&fin);
    QString line = in.readLine();
    int cont=0;
    int canales=signal->getCanales().toInt()+1;
    while (!line.isNull()) {
        QStringList strList;
        strList = line.split(" ");
        qDebug()<<"size lista"<<strList.size()<<" linea "<<line;
        if(( strList.size() )!=canales){
            qDebug()<<"el Numero de canales no coincide";
            return false;
        }
        signal->readSignal.resize(canales);
        //signal->getreadSignal().resize(canales);
        qDebug()<<"size"<<signal->getreadSignal().size()<<"canales "<<canales;
        for (int i = 0; i < canales; i++){
            (signal->readSignal)[i].append( QString(strList.at(i)).toDouble() );
            //qDebug()<<(signal->getreadSignal())[i].at(cont)<<" ";
        }

        cont++;
        line = in.readLine();
    }
    qDebug()<<"cantidad de lineas leidas"<<cont;
    return true;
}



void MainWindow::on_pushButton_2_clicked(){

    dialogoFile=new CargaDatos();
    connect(dialogoFile,SIGNAL( lecturaAceptada(Signal*) ),
            this,SLOT( setDatos(Signal*) ) );
    dialogoFile->exec();
    dialogoFile->close();

}
