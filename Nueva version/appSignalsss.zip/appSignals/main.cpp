#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    int final;
    if(w.levantarServicios()){
        w.show();
        final=a.exec();
    }else
        final=-1;

    return final;
}
