#include "cargadatos.h"
#include "ui_cargadatos.h"

CargaDatos::CargaDatos(QWidget *parent) : QDialog(parent), ui(new Ui::CargaDatos){

    ui->setupUi(this);
    signal=new Signal();

    ui->listWidget->setViewMode(QListWidget::IconMode);
    ui->listWidget->setIconSize(QSize(96, 84));
    ui->listWidget->setMovement(QListWidget::Static);
    ui->listWidget->setMaximumWidth(128);
    ui->listWidget->setSpacing(12);
    ui->listWidget->setCurrentRow(0);
    ui->stackedPages->setCurrentIndex(0);
    connect(ui->listWidget,SIGNAL(currentRowChanged(int)),ui->stackedPages,SLOT(setCurrentIndex(int)));
    connect(ui->ButtonFileTxt,SIGNAL(clicked()),this,SLOT(fileChooser() ) );
    connect(ui->ButtonFileCsv,SIGNAL(clicked()),this,SLOT(fileChooser() ) );


}

CargaDatos::~CargaDatos(){
    delete ui;
}


void CargaDatos::on_ButtonAccept_clicked(){


    QString channel,sep;

    if(ui->stackedPages->currentWidget()==ui->pageTxt){
        signal->setCanales(ui->comboTxtChannels->currentText());
        signal->setFs(ui->lineEditTxtFs->text());
        signal->setPath(ui->lineEditPathTxt->text());
    }else{
        signal->setCanales(ui->comboCsvChannels->currentText());
        signal->setFs(ui->lineEditCsvFs->text());
        signal->setPath(ui->lineEditPathCsv->text());
        //signal->setLeerDesde(ui->comboCsvSep->text);
    }

    emit lecturaAceptada(signal);
}


/**********************************************************
 * @name:fileChooser
 * @brief: abre un dialogo para seleccionar un archivo del tipo seleccionado
 * @throw: indica q se puede dar una excepcion y  cual es.
 * @warnig: advertencia de ocupar el fragmento de codigo
 * ********************************************************/
void CargaDatos::fileChooser(){

    QString path,tipo,tipoFile;
    tipoFile=ui->listWidget->currentItem()->text();
    tipo=( tipoFile.toUpper() )+" Files (*."+(tipoFile.toLower())+")";
    path=QFileDialog::getOpenFileName(this, "Abrir Archivo - EMG",
                                        "/home/cesar/",tipo);

    if(path!=NULL){
        QFile fin(path);
        if (!fin.open(QIODevice::ReadOnly | QIODevice::Text)){
            QMessageBox msgBox;
            msgBox.setText("No se pudo abrir el archivo seleccionado");
            msgBox.exec();
            return;
        }else{
            habilita(tipoFile.toLower(),path);
        }
    }
}

void CargaDatos::habilita(QString tipo,QString path){

    if(tipo=="txt"){
        ui->groupBoxParamTxt->setEnabled(true);
        ui->lineEditPathTxt->setText(path);

    }else
        if(tipo=="csv"){
            ui->groupBoxParamCsv->setEnabled(true);
            ui->lineEditPathCsv->setText(path);
        }else
            qDebug()<<"error en el tipo de dato";

}
